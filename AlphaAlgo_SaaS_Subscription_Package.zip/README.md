# AlphaAlgo Pro SaaS & Subscription Engine

Is package me complete Algo Trading SaaS Dashboard tayyar hai jisme:
1. **Google Login Mock / Multi-User System:**
   - Har user ka apna account, email aur subscription plan hota hai.
2. **Free vs Pro Feature Tiering:**
   - **Free Users:** Sirf Paper Trading chalega, daily max 2 trades execute honge, aur Live Broker API lock rahega.
   - **Pro Users:** Unlimited trades, Live Broker API unlock, Trailing Stop-Loss active.
3. **Master Admin Dashboard (Aapke liye):**
   - Click "👑 Admin Console" (Admin login par dikhta hai).
   - Saare registered users ki list, unke plans dekhein.
   - 1-Click me kisi bhi user ko Free se Pro grant karein.
   - Custom Promo Codes banayein (jaise `VIPPASS`, `FREE2026`) jo aap kisi ko bhi dekar unhe free me Pro plan de sakte hain.
4. **Editable & Fully Customizable:**
   - Ye standard clean HTML/Tailwind/JS code hai jise aap kisi bhi text editor (Notepad, VS Code) me open karke colors, brokers, text ya pricing 2 minute me modify kar sakte hain.

## 🚀 Run Kaise Karein:
1. `index.html` par double click karein.
2. Login screen par **Admin** ya **User** choose karke pura SaaS flow test karein!
